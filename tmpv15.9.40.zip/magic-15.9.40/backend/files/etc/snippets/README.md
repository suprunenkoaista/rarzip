# Hyperlambda Snippets

This folder contains your persisted Hyperlambda snippets. The _"Eval"_ menu item uses this
folder to store and read snippets as you use the load and save features of it to store
frequently used Hyperlambda snippets.
