
# SQL Server related files

This folder contains Microsoft SQL Server related files, such as for instance SQL server
related snippets.
