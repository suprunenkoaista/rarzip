
# Your own assumptions

This folder is for your own custom assumptions which serves almost like unit tests or _"integration tests"_ for
your own custom code.
