
# SQLite samples scripts

This folder contains example scripts for SQLite, such as for instance SQL scripts creating databases, etc for you.
