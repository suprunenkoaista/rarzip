
# PostgreSQL related files

This folder contains PostgreSQL related files, such as for instance MySQL
related snippets.
