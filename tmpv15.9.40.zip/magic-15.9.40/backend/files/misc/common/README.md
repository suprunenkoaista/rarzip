
# Common 'database' files

Files to insert default data and performs similar tasks after database has been created.
