
alter table ml_training_snippets add embedding ntext null;
