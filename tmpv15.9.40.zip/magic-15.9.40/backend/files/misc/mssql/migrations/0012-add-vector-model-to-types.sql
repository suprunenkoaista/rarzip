
alter table ml_types add vector_model nvarchar(1024) not null default 'text-embedding-ada-002';
