
alter table ml_types add max_context_tokens int;
alter table ml_types add max_request_tokens int;

