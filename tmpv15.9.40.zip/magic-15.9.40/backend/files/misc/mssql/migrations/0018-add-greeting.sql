
alter table ml_types add greeting ntext null;

