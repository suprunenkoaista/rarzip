
alter table ml_training_snippets add filename varchar(1024) null;
