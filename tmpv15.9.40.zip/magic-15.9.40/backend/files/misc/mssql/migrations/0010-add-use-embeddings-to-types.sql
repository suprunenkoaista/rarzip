
alter table ml_types add use_embeddings int not null default 0;
