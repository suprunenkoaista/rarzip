
alter table ml_types add prefix ntext null;
