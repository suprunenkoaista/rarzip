
# Assumption/integration tests

This folder contains your persisted assumption tests. An assumption test is a serialized HTTP invocation,
that can be replayed, and as it is replayed, assumptions about its result are verified.

Think of these as _"integration tests"_ if it helps, although they're technically not completely the
same thing.
