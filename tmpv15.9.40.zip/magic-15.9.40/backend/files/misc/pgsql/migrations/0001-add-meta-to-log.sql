
alter table log_entries add column meta text null;
