
alter table ml_types add column threshold real not null default 0.8;
