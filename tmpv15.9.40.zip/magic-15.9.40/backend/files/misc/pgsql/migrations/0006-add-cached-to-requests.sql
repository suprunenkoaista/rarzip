
alter table ml_types add column cached smallint not null default 0;
