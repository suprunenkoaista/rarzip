
create unique index crypto_keys_fingerprint_unique on crypto_keys(fingerprint);
