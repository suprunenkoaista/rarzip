
alter table ml_types add column vector_model varchar(1024) not null default 'text-embedding-ada-002';
