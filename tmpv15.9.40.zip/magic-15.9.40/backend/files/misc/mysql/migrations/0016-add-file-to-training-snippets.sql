
alter table ml_training_snippets add column filename varchar(1024) null;
