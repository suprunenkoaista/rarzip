
alter table log_entries add meta text null after content;
