
alter table ml_types add column max_context_tokens int;
alter table ml_types add column max_request_tokens int;

