
alter table ml_types add column threshold decimal(7,6) not null default 0.8;
