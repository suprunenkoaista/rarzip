
# SQLite migration scripts

This folder contains your database migration scripts, that are executed during startup, to ensure your
database is updated and changed according to the requirements of the version you're currently running.
