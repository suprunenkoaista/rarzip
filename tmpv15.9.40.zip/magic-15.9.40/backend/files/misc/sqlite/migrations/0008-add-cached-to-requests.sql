
alter table ml_requests add column cached integer null;
