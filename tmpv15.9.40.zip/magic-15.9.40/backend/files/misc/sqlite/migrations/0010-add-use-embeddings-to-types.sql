
alter table ml_types add column use_embeddings integer not null default 0;
