
# Macros for Hyper IDE

This folder contains all Hyperlambda macros for Hyper IDE. A macro is a Hyperlambda snippet that
typically creates code, endpoints, and/or folders for you. You can parametrise a macro dynamically,
changing how it behaves, resulting in changing its generated code.
