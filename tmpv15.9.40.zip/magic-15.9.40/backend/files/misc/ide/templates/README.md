
# Template files for Hyper IDE

This folder contains template files for Hyper IDE. You can create your own template files
within this folder if you wish.

