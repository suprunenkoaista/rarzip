
# SQL Server database migration scripts

This folder contains your SQL Server database migration scripts, and each SQL scripts will be sequentially
executed in alphabetical order.

