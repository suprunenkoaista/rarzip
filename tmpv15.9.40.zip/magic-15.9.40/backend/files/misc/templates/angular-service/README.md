
# Angular HTTP Service template

This template will *only* generate an HTTP service layer for you, with some helper
functionality, such as automatically injecting your JWT token if authenticated as
an HTTP Bearer Authorization token into your requests towards your backend.
