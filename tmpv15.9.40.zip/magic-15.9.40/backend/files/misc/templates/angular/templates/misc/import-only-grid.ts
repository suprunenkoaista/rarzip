import { [[component-name]] } from '../components/[[component-folder]]/[[component-filename]]';
