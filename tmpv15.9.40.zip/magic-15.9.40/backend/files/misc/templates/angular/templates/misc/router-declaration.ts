    { path: 'crud/[[router-url]]', component: [[component-name]], data: { title: marker('[[router-url]]') } },
