  public _[[form-control-name]]: FormControl;
