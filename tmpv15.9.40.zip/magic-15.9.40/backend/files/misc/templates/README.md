
# Your endpoints template folder

This folder contains templates for generating _"something"_ out of your endpoints, and among
other things, is the folder where the frontend scaffolders can be found in Magic. You can
create your own templates here, by starting out with for instance the _"/anglar-default/"_
template as your starting point.
